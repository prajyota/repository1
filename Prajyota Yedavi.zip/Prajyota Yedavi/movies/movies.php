<?php
require_once 'connect.php';

?>


<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style >
nav ,footer{
 
overflow: hidden;
  background-color: #333;
}
h2{
  color: white;

}
nav a{
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

nav a:hover{

  background-color: #ddd;
  color: black;
}

nav a.active {
  background-color: #179;
  color: white;
}
div.content{
  float: bottom;
}
</style>

</head>
<body>
<nav><h2>Short Film Window</h2></br>
  <a href="home.php">Home</a> 
  <a href="movies.php" class="active">Movies</a> 
  <a href="contact.php">contact us</a> 
 
</nav>
<div  class="content">
<h2>Explore </h2>
</br>
<div class="search-container">
    <form action="" method="POST">
      
      <input type="text" name="name" id="name">
   <input type="submit" value="Search" name="submit">
    </form>
  </div>

    <!--filter -->
    <h2>Filter</h2>
  <div>
  <form  method="POST" action="" >Genre :
<select name="genreselect">
<option value="all" selected="selected">All </option>
<option value="comedy">comedy</option> 
<option value="horror">horror</option> 
<option value="Sci Fi">Sci Fi </option> 
</select> 
<input type="Submit" value="Submit" name="Submit"> 
</form>
</div>



<div>
<form  method="POST" >
language:
  
<select name="langselect">
  <option value="all" selected="selected">All </option>
<option value="hindi">Hindi</option> 
<option value="english">English</option> 

</select> 
<input type="Submit" value="Submit" name="Submit"> 
</form>
</div>

<div>
<form  method="POST" >
sort:
  
<select name="sort">
 
<option value="hindi">duration</option>
 

</select> 
<input type="Submit" value="Submit" name="Submit"> 
</form>
</div>

  <?php
  //search
   if(isset($_REQUEST['submit']))
    {

  $name = $_POST['name'];
  $allmovie="SELECT * from movie WHERE name='$name' ";
  
    foreach ($con->query($allmovie) as $row){
      if(!empty($row)){
    $name=$row["name"]; 
    $genre=$row["genre"];
    $length=$row["duration"];
    $language=$row["language"];
    $director=$row["director"];

    

   $imgu=$row["img_url"];
     echo"<table><tr><td>";  
     echo "<img  style=width:200px; height:200px; src=".$imgu." />";  
     
    echo "</td> <td>";

    echo "<div float:left;>";
    echo '<h3><a style="text-decoration:none" href="details.php?name='.$name.'">'.$name.'</a></h3></br>';
  echo  $genre."</br>" ;
    echo $language."</br>";
    echo $length."min </br>";
    echo $director."</br>";
    echo "</div>";
    echo "</td></tr></table>";
  }else{

     echo "<h3> no results found!!!</h3>";
      

  }
}
  
 
    } 

  

if(isset($_POST['genreselect']))
    {

 $genre = $_POST['genreselect'];
 if($genre=='all'){
  $gq="SELECT * from movie ";
 }else{
  $gq="SELECT * from movie where genre='$genre' ";
 }
   
    foreach ($con->query($gq) as $row1){
   $name=$row1["name"]; 
    $genre=$row1["genre"];
    $length=$row1["duration"];
    $language=$row1["language"];
    $director=$row1["director"];

    

   $imgu=$row1["img_url"];
     echo"<table><tr><td>";  
     echo "<img  style=width:200px; height:200px; src=".$imgu." />";  
     
    echo "</td> <td>";

    echo "<div float:left;>";
    echo '<h3><a style="text-decoration:none" href="details.php?name='.$name.'">'.$name.'</a></h3></br>';
  echo  $genre."</br>" ;
    echo $language."</br>";
    echo $length."min </br>";
    echo $director."</br>";
    echo "</div>";
    echo "</td></tr></table>";
}
  
 
    }

    if(isset($_POST['langselect']))
    {

 $language = $_POST['langselect'];
 if($language=='all'){
  $gq="SELECT * from movie ";

 }
 else{


  $gq="SELECT * from movie where language='$language' ";
  
   
   }
 
  foreach ($con->query($gq) as $row2){
     
   $name=$row2["name"]; 
    $genre=$row2["genre"];
    $length=$row2["duration"];
    $language=$row2["language"];
    $director=$row2["director"];

    

   $imgu=$row2["img_url"];
     echo"<table><tr><td>";  
     echo "<img  style=width:200px; height:200px; src=".$imgu." />";  
     
    echo "</td> <td>";

    echo "<div float:left;>";
   echo '<h3><a style="text-decoration:none" href="details.php?name='.$name.'">'.$name.'</a></h3></br>';
  echo  $genre."</br>" ;
    echo $language."</br>";
    echo $length."min </br>";
    echo $director."</br>";
    echo "</div>";
    echo "</td></tr></table>";
}
    }

//duration
    if(isset($_POST['sort']))
    {

 $sort = $_POST['sort'];
   $gq="SELECT * from movie ORDER BY duration ";
  
  foreach ($con->query($gq) as $row2){
     
   $name=$row2["name"]; 
    $genre=$row2["genre"];
    $length=$row2["duration"];
    $language=$row2["language"];
    $director=$row2["director"];

    

   $imgu=$row2["img_url"];
     echo"<table><tr><td>";  
     echo "<img  style=width:200px; height:200px; src=".$imgu." />";  
     
    echo "</td> <td>";

    echo "<div float:left;>";
    echo '<h3><a style="text-decoration:none" href="details.php?name='.$name.'">'.$name.'</a></h3></br>';
  echo  $genre."</br>" ;
    echo $language."</br>";
    echo $length."min </br>";
    echo $director."</br>";
    echo "</div>";
    echo "</td></tr></table>";
}
    }

?>
</div>


<footer>
  <p>

ShortFilmWindow | All Rights Reserved.</p>
</footer>

</body>
</html>