

<html>
<head>
   
<style >
nav,footer {
 
overflow: hidden;
  background-color: #333;
}

nav a{
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

nav a:hover{

  background-color: #ddd;
  color: black;
}

nav a.active {
  background-color: #179;
  color: white;
}

.image { 
   position: relative; 
}

h2 { 
   position: absolute; 
   bottom: 0; 
   left: 0; 
   color: white;
}
div.content{
  float: bottom;
}

</style>

</head>
<body>
<nav><h2>Short Film Window</h2></br>
  <a href="home.php" class="active">Home</a> 
  <a href="movies.php">Movies</a> 
  <a href="contact.php">contact us</a> 
 
</nav>
<div class="content">

<?php  require_once 'connect.php'; 

if(isset($_GET['name'])){
  $name=$_GET['name'];
  $moviedetails = "SELECT * from movie where name='$name'"; 
  
  foreach ($con->query($moviedetails) as $row){
     $name=$row["name"]; 
    $genre=$row["genre"];
    $language=$row["language"]; 
     $id=$row["id"];
     $imgu=$row["img_url"];
      $duration=$row["duration"];
      $director=$row["director"];
      $description=$row["description"];
  
  echo "<h3>".$name."</h3>";
     echo "<img  style=width:400px; height:400px; src=".$imgu." /> </br>"; 
     echo  $genre."</br>" ;
    echo $language."</br>";
    echo $duration."min </br>";
    echo "Directed by:".$director." </br>";
    echo $description;
    echo "</div>";
    echo "</td></tr></table>";


  } 
}

 ?>
</div>
 <footer>
  <p>

ShortFilmWindow | All Rights Reserved.</p>
</footer>  

</body>
</html>