<html>
<head>
<style >
nav,footer {
 
overflow: hidden;
  background-color: #333;
}

nav a{
	float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

nav a:hover{

  background-color: #ddd;
  color: black;
}
nav a.active {
  background-color: #179;
  color: white;
}
h2{
  color: white;

}
div.content{
  float: bottom;
}
</style>
</head>
<body>
	<nav><h2>Short Film Window</h2></br>
  <a href="home.php">Home</a> 
  <a href="movies.php">Movies</a> 
  <a href="contact.php" class="active">contact us</a> 
 
</nav>
<div class="content">
<pre>You can visit us at :
302, Hill View 2,
Above DCB Bank,
Opp. Mehboob Studio
Hill Road
Bandra West
Mumbai  400050

 

You may send your Film with a DVD to above address.

For any issues 
contact us at: shortfilmwindow@gmail.com</pre>

</div>
<footer>
  <p>

ShortFilmWindow | All Rights Reserved.</p>
</footer>
</body>
</html>

