<html>

<head>
<title>Connecting to database</title>

</head>

<body>
<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "movies";

try
{
   
  $con = new PDO("mysql:host={$host};dbname={$db}",$user,$pass); 

  
}
catch (Exception $e)
{
  echo "Unable to connect: " . $e->getMessage() ."<p>";
}

?>

</body>
</html>
