<?php  require_once 'connect.php';  ?>

<html>
<head>
   
<style >
nav,footer {
 
overflow: hidden;
  background-color: #333;
}

nav a{
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

nav a:hover{

  background-color: #ddd;
  color: black;
}

nav a.active {
  background-color: #179;
  color: white;
}
h2{
  color: white;

}
div.content{
  float: bottom;
}
</style>

</head>
<body>
<nav><h2>Short Film Window</h2></br>
  <a href="home.php" class="active">Home</a> 
  <a href="movies.php">Movies</a> 
  <a href="contact.php">contact us</a> 
 
</nav>


    <div class="content">

<?php  
 $allmovie="SELECT * from movie  ";
 foreach ($con->query($allmovie) as $row){
    $name=$row["name"]; 
    $genre=$row["genre"];
    $language=$row["language"]; 
   $id=$row["id"];
     $imgu=$row["img_url"];
     echo"<table><tr><td>";  
     echo "<img  style=width:200px; height:200px; src=".$imgu." />";  
     
    echo "</td> <td>";

    echo "<div float:left;>";

      echo '<a style="text-decoration:none" href="details.php?name='.$name.'">'.$name.'</a></br>'; 

   // echo "<h3> <a href=details.php?name='$name'>".$name."</a></h3>";
  echo  $genre."</br>" ;
    echo $language;
    echo "</div>";
    echo "</td></tr></table>";

    
  
 
   }
?>
 
    </div>

<footer>
  <p>

ShortFilmWindow | All Rights Reserved.</p>
</footer>
</body>
</html>