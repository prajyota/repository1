-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2018 at 08:31 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `movies`
--

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE IF NOT EXISTS `movie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `language` varchar(20) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `duration` double NOT NULL,
  `director` varchar(20) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `img_url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`id`, `name`, `language`, `genre`, `duration`, `director`, `description`, `img_url`) VALUES
(1, 'THE NOSTALGIST', 'english', 'Sci Fi', 17, 'Giacomo Cimini', 'The Nostalgist is based on a short story by Daniel H Wilson (Robopocalypse) and was created as a result of a successful Kickstarter campaign that raised £32,000.The film begins with a father and son playing chess in their cosy Victorian-era home. After some trouble with his glasses, the father leaves to get new ones, and both are thrust into a nightmare. Moving between two worlds, the film uses the contrast between them to tell a dark, thrilling and sad story about the lies we tell ourselves and', 'images_file/nostalgist.jpg'),
(3, 'HYPER-REALITY', 'english', 'Sci Fi', 6, 'Keiichi Matsuda', 'Virtual Reality has been around in some form or other since the 80''s, and as an idea much earlier in science fiction novels. It only now seems like we are ready to welcome it into our homes. The tech is getting cheaper, we are very comfortable living with screens, and anyway something needs to be totally immersive to grab our attention. Which is the only value we have for most corporations, brands, religions, institution, etc., our collective ability to pay attention to them.  But with all the tech demos, the swimming with sharks-walking on lava, computer engines that will generate environment in real-time, there is an underlying anxiety. There is a fear that like anything mass produced in the previous century, it will be used for narcotic escapism, to forget who we are or where we are. Hyper-Reality is about that fear.', 'images_file/hyperreality.jpg'),
(4, 'LESLEY', 'english', 'comedy', 10, 'Craig Ainsley', 'An actor flees to the woods to read Carl Sagan''s Cosmos, and to reconnect with nature, but the world has a way of finding you. Or actually eluding you just when you need those sweet network bars on your phone.  "Lesley" is the name of the Arj''s agent and his only connection to the outside world. You see the actor fumble in the woods trying to reach his agent, record an audition and send it, get lost and then try to find his way back. In some way, it''s the story of a man and his relationship with his phone.  The actor Arnab Chanda takes center-stage and is superb. He keeps his character real and relatable even as he gets into almost slapstick comedy mode. ', 'images_file/lesley.jpg'),
(5, 'TAANDAV', 'hindi', 'comedy', 11, 'Devashish Makhija', 'Tambe, the head constable at the center of the story, is a so constrained in his circumstances that the frame literally closes around him. Standing up for some kind of personal principles costs him the attention of his wife, loyalty of his colleagues, and maybe the love of his daughter. And then the world won''t shut up around him. The accusing glances surround him and the noise beats him down. So sometimes the only way to break through a wall is to crash through it.', 'images_file/taandav.jpg'),
(6, 'TOTAL INTERNAL REFLECTION', 'hindi', 'horror', 11, 'Rahul Prakash', 'A photographer rushes out for work, promising his autistic brother that he will return with dinner. The slamming of the door causes a box to drop at the brother''s feet. And the brother sees something that changes him. The film expands on this unusual premise and reaches for some really dark moments. In simple terms, this is a horror film, about the ghost of a woman who haunts an apartment. But the addition of a photographer filled with violence, the ideas thrown into the mix, the very intelligent use of reflective surfaces and compositions give the film a very visceral & strange flavor. This is unlike any horror short you will see this year and it has a killer last shot.', 'images_file/Total_Internal_Reflection.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
